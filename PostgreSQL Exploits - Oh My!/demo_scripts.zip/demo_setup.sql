/*
 * Create a non-superuser ROLE
 */
CREATE USER pgspot WITH PASSWORD 'superspy';
ALTER ROLE pgspot CREATEROLE;
ALTER ROLE pgspot NOSUPERUSER;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO pgspot;

/*
 * This is the query behind psql \du
 */
SELECT r.rolname, r.rolsuper, r.rolinherit,
  r.rolcreaterole, r.rolcreatedb, r.rolcanlogin,
  r.rolconnlimit, r.rolvaliduntil,
  ARRAY(SELECT b.rolname
        FROM pg_catalog.pg_auth_members m
        JOIN pg_catalog.pg_roles b ON (m.roleid = b.oid)
        WHERE m.member = r.oid) as memberof
, r.rolreplication
, r.rolbypassrls
FROM pg_catalog.pg_roles r
WHERE r.rolname !~ '^pg_'
ORDER BY 1;


/*
 * Verify that the user is NOT a superuser.
 */
SELECT * FROM pg_catalog.pg_roles
WHERE rolsuper=true;

