-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION hello_postgres" to load this file. \quit


CREATE TABLE "language" (
	id int PRIMARY KEY,
	abbreviation varchar(5) NOT NULL,
	name TEXT NOT NULL
);

CREATE TABLE "greeting" (
	id int PRIMARY KEY,
	greeting_text TEXT NOT NULL,
	language_id int REFERENCES "language" (id)
);

INSERT INTO "language" VALUES
 (1,'US','US English'),
 (2,'UK','UK English'),
 (3,'FR','French'),
 (4,'ES','Spanish'),
 (5,'DE','German'),
 (6,'AU','Australia English'),
 (7,'PT','Portuguese');

INSERT INTO "greeting" VALUES 
 (1,'Hello, PostgreSQL!',1),
 (2,'Hello, Postgres!',1),
 (3,'Howdy, partner! Yee-haw Postgres!',1),
 (4,'''ello Postgres!',2),
 (5,'Why, hello there, Postgres.',2),
 (6,'That''s just 🍌, Postgres!',2),
 (7,'Bonjour Postgres!',3),
 (8,'Hola Postgres!',4),
 (9,'Hallo, Postgres!',5),
 (10,'Hey Postgres! G''day Mate!',6),
 (11,'Olá, Postgres!',7);
 

CREATE FUNCTION hello_postgres(lid int)
RETURNS TEXT 
SET search_path= pg_catalog, pg_temp
LANGUAGE plpgsql
AS $$ 
	DECLARE response_text TEXT;
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM public."language" WHERE id=lid) THEN 
			RAISE EXCEPTION 'Language id provided does not yet exist';
		END IF;
		
		SELECT greeting_text INTO response_text FROM public.greeting WHERE language_id=lid
		ORDER BY random()
		LIMIT 1;
	
	return(response_text);
	END;
$$;

CREATE FUNCTION hello_postgres(lcode text)
RETURNS TEXT 
LANGUAGE plpgsql 
AS $$ 
	DECLARE response_text TEXT;
	BEGIN
		/*
		 * Option 2: Reference the exact OPERATOR
		 */
		IF NOT EXISTS(SELECT 1 FROM public."language" WHERE abbreviation OPERATOR(pg_catalog.=) lcode) THEN 
			RAISE EXCEPTION 'Language code provided is not supported.';
		END IF;
		
		SELECT greeting_text INTO response_text FROM greeting g
			INNER JOIN "language" l ON g.language_id=l.id 
		WHERE abbreviation OPERATOR(pg_catalog.=) lcode
		ORDER BY random()
		LIMIT 1;
	
	return(response_text);
	END;
$$;

