﻿CREATE TABLE [ref].[SearchTerms] (
    [SearchTermId] INT      IDENTITY (1, 1) NOT NULL,
    [Trigram]      CHAR (3) NOT NULL,
    [FirstNameId]  INT      NOT NULL,
    CONSTRAINT [PKC_SearchTermId] PRIMARY KEY CLUSTERED ([SearchTermId] ASC)
);
GO

CREATE NONCLUSTERED INDEX [IX_Trigram_FirstNameId]
    ON [ref].[SearchTerms]([Trigram] ASC) WITH (DATA_COMPRESSION = ROW);
GO