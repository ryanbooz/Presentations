﻿CREATE TABLE [ref].[FirstName] (
    [FirstNameId]     INT           IDENTITY (1, 1) NOT NULL,
    [FirstName]       VARCHAR (255) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    [FirstReportYear] INT           NOT NULL,
    [LastReportYear]  INT           NOT NULL,
    [TotalNameCount]  BIGINT        NOT NULL,
    [NameLength]      AS            (len([FirstName])),
    CONSTRAINT [pk_FirstName_FirstNameId] PRIMARY KEY CLUSTERED ([FirstNameId] ASC)
);

