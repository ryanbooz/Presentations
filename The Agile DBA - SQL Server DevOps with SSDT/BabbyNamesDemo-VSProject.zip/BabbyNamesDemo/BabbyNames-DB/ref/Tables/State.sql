﻿CREATE TABLE [ref].[State] (
    [StateCode] CHAR (2)      COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    [StateName] VARCHAR (128) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    CONSTRAINT [pk_ref_State] PRIMARY KEY CLUSTERED ([StateCode] ASC)
);

