﻿

-- Step 8: Create Function to get IDs of the trigrams that match the top three
CREATE FUNCTION ref.GetTrigramMatchIDs
(
    @Trigram1 char(3),
    @Trigram2 char(3),
    @Trigram3 char(3)
)
RETURNS @IDs table (id integer PRIMARY KEY)
WITH SCHEMABINDING AS
BEGIN
    IF  @Trigram1 IS NOT NULL
    BEGIN
        IF @Trigram2 IS NOT NULL
        BEGIN
            IF @Trigram3 IS NOT NULL
            BEGIN
                -- 3 Trigrams available
                INSERT @IDs (id)
                SELECT ET1.FirstNameId
                FROM ref.SearchTerms AS ET1 
                WHERE ET1.Trigram = @Trigram1
                INTERSECT
                SELECT ET2.FirstNameId
                FROM ref.SearchTerms AS ET2
                WHERE ET2.Trigram = @Trigram2
                INTERSECT
                SELECT ET3.FirstNameId
                FROM ref.SearchTerms AS ET3
                WHERE ET3.Trigram = @Trigram3
                OPTION (MERGE JOIN);
            END;
            ELSE
            BEGIN
                -- 2 Trigrams available
                INSERT @IDs (id)
                SELECT ET1.FirstNameId
                FROM ref.SearchTerms AS ET1 
                WHERE ET1.Trigram = @Trigram1
                INTERSECT
                SELECT ET2.FirstNameId
                FROM ref.SearchTerms AS ET2
                WHERE ET2.Trigram = @Trigram2
                OPTION (MERGE JOIN);
            END;
        END;
        ELSE
        BEGIN
            -- 1 Trigram available
            INSERT @IDs (id)
            SELECT ET1.FirstNameId
            FROM ref.SearchTerms AS ET1 
            WHERE ET1.Trigram = @Trigram1;
        END;
    END;
 
    RETURN;
END;