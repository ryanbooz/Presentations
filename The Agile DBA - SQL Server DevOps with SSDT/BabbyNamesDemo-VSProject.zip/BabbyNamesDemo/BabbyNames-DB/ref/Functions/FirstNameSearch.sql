﻿

-- Step 9: Finally, return the FirstNames that match the top three trigrams
CREATE FUNCTION ref.FirstNameSearch
(
    @Search varchar(255)
)
RETURNS table
WITH SCHEMABINDING
AS
RETURN
    SELECT
        Result.FirstName, Result.FirstNameId
    FROM ref.GetBestTrigrams(@Search) AS GBT
    CROSS APPLY
    (
        -- Trigram search
        SELECT
            FN.FirstNameId,
            FN.FirstName
        FROM ref.GetTrigramMatchIDs
            (GBT.trigram1, GBT.trigram2, GBT.trigram3) AS MID
        JOIN ref.FirstName AS FN
            ON FN.FirstNameId = MID.id
        WHERE
            -- At least one trigram found 
            GBT.trigram1 IS NOT NULL
            --AND FN.FirstName LIKE @Search
 
) AS Result;