﻿

-- Step 7: Get the top three trigrams that have the highest count of usage - the most popular
CREATE FUNCTION ref.GetBestTrigrams (@string varchar(255))
RETURNS table
WITH SCHEMABINDING AS
RETURN
    SELECT
        -- Pivot
        trigram1 = MAX(CASE WHEN BT.rn = 1 THEN BT.trigram END),
        trigram2 = MAX(CASE WHEN BT.rn = 2 THEN BT.trigram END),
        trigram3 = MAX(CASE WHEN BT.rn = 3 THEN BT.trigram END)
    FROM 
    (
        -- Generate trigrams for the search string
        -- and choose the most selective three
        SELECT TOP (3)
            rn = ROW_NUMBER() OVER (
                ORDER BY FNC.cnt ASC),
            GT.trigram
        FROM ref.GenerateTrigrams(@string) AS GT
        JOIN ref.FirstNameCounts AS FNC
            WITH (NOEXPAND)
            ON FNC.Trigram = GT.trigram
        ORDER BY
            FNC.cnt ASC
    ) AS BT;