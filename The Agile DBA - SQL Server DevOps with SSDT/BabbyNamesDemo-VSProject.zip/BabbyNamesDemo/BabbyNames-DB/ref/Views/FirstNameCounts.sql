﻿CREATE VIEW ref.FirstNameCounts
WITH SCHEMABINDING
AS
	SELECT ST.Trigram, cnt = COUNT_BIG(*)
	FROM ref.SearchTerms AS ST
	GROUP BY ST.Trigram;
GO
CREATE UNIQUE CLUSTERED INDEX [CUX_FirstNameCounts_Trigram]
    ON [ref].[FirstNameCounts]([Trigram] ASC);

