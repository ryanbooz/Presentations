﻿CREATE PROC [ref].[FindBabyNames]
	@topN int = 10,
	@name varchar(20) = 'Ryan',
	@startYear int = 1900,
	@numberOfYears int = 10
AS
BEGIN

	DECLARE @endYear INT = @startYear+@numberOfYears;

	SELECT TOP(@topN) FNS.FirstName, A.Gender, SUM(A.totalCount) TotalNameCount FROM ref.FirstNameSearch(@name) AS FNS
	CROSS APPLY (
		-- This TOP (max INT) tricks the planner into doing this search 
		-- like I want it to since I know my data
		SELECT TOP(2147483647) B.Gender, B.totalCount FROM 
		( 
			SELECT FNBY.Gender, FNBY.NameCount totalCount FROM agg.FirstNameByYear FNBY
			WHERE
				FNBY.firstNameID = FNS.firstNameId AND 
				FNBY.ReportYear >=@startYear AND fnby.reportyear < @endYear
		) B
	) A
	GROUP BY FNS.FirstName, A.Gender
	ORDER BY TotalNameCount DESC

END