﻿CREATE PROC [ref].[GenerateSearchTerms]
AS
BEGIN

	INSERT ref.SearchTerms WITH (TABLOCKX)
		 (Trigram, FirstNameId)
	SELECT
		GT.trigram,
		FN.FirstNameId
	FROM ref.FirstName AS FN
	CROSS APPLY ref.GenerateTrigrams(FN.FirstName) AS GT;

END