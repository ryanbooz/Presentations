﻿CREATE SCHEMA [evt]
    AUTHORIZATION [dbo];

