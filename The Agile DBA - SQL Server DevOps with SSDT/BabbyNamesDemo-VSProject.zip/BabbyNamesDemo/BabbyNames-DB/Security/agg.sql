﻿CREATE SCHEMA [agg]
    AUTHORIZATION [dbo];



