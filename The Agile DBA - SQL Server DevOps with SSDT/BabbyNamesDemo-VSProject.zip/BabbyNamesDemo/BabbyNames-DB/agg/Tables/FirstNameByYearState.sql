﻿CREATE TABLE [agg].[FirstNameByYearState] (
    [ReportYear]  INT      NOT NULL,
    [StateCode]   CHAR (2) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    [FirstNameId] INT      NOT NULL,
    [Gender]      CHAR (1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    [NameCount]   INT      NOT NULL,
    CONSTRAINT [pk_aggFirstNameByYearState] PRIMARY KEY CLUSTERED ([ReportYear] ASC, [StateCode] ASC, [FirstNameId] ASC, [Gender] ASC),
    CONSTRAINT [fk_FirstNameByYearState_FirstName] FOREIGN KEY ([FirstNameId]) REFERENCES [ref].[FirstName] ([FirstNameId])
);

