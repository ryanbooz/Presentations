﻿CREATE TABLE [agg].[FirstNameByYear] (
    [ReportYear]  INT      NOT NULL,
    [FirstNameId] INT      NOT NULL,
    [Gender]      CHAR (1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
    [NameCount]   INT      NOT NULL,
    CONSTRAINT [pk_aggFirstNameByYear] PRIMARY KEY CLUSTERED ([ReportYear] ASC, [FirstNameId] ASC, [Gender] ASC),
    CONSTRAINT [fk_FirstNameByYear_FirstName] FOREIGN KEY ([FirstNameId]) REFERENCES [ref].[FirstName] ([FirstNameId])
);




GO
CREATE NONCLUSTERED INDEX [IX_FirstNameByYear_FirstNameId_ReportYear]
    ON [agg].[FirstNameByYear]([FirstNameId] ASC, [ReportYear] ASC);

