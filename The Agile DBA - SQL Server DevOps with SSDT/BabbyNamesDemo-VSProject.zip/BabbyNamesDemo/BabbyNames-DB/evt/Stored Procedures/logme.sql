﻿
CREATE PROCEDURE evt.logme
	@msg NVARCHAR(MAX)
AS
	SET NOCOUNT ON;

	DECLARE @ver NVARCHAR(128);
	SET @ver = N'(ver 1_300) ';

	SET @msg=@ver+@msg;

	DECLARE @msgtime NVARCHAR(24);
	SET @msgtime = CONVERT(NVARCHAR(21), SYSDATETIME(), 121) +  N': ';

	IF OBJECT_ID ('evt.Log') IS NOT NULL
		INSERT evt.Log (LogEntry) VALUES (@msg);

	SET @msg=@msgtime+@msg;
	RAISERROR (@msg, 0, 1) WITH NOWAIT;
