﻿CREATE TABLE [evt].[Log] (
    [LogId]    INT            IDENTITY (1, 1) NOT NULL,
    [LogDate]  DATETIME2 (0)  CONSTRAINT [df_LogDate_sysdatetime] DEFAULT (sysdatetime()) NOT NULL,
    [LogEntry] NVARCHAR (MAX) COLLATE SQL_Latin1_General_CP1_CS_AS NULL,
    CONSTRAINT [pk_evtLog] PRIMARY KEY CLUSTERED ([LogId] ASC)
);

